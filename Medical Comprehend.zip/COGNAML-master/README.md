# COGNAML
Medical entity extraction 

tensorflow implementation of Name Entity Extraction using Bi-LSTM with character level embedding

note:
download glove embedding weights from the below link named : glove.6gb
unzip and keep the folder inside data folder

https://nlp.stanford.edu/projects/glove/

Python files:

Medical_train.py --> is to train the model

Medical_test.py --> is to test the model by giving user input 

